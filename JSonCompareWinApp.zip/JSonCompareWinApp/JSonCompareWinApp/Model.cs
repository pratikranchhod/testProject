﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JSonCompareWinApp
{
    public class IntegrationProfile
    {

        [JsonProperty("request")]
        public Request Request { get; set; }

        [JsonProperty("response")]
        public Response Response { get; set; }
    }

    public class Request
    {

        [JsonProperty("returnRequest")]
        public bool ReturnRequest { get; set; }

        [JsonProperty("requestId")]
        public string RequestId { get; set; }

        [JsonProperty("maxRecords")]
        public int MaxRecords { get; set; }
    }

    public class Propertie
    {

        [JsonProperty("createdService")]
        public string CreatedService { get; set; }

        [JsonProperty("createdBy")]
        public string CreatedBy { get; set; }

        [JsonProperty("createdDate")]
        public DateTime CreatedDate { get; set; }

        [JsonProperty("modifiedService")]
        public string ModifiedService { get; set; }

        [JsonProperty("modifiedBy")]
        public string ModifiedBy { get; set; }

        [JsonProperty("modifiedDate")]
        public DateTime ModifiedDate { get; set; }

        [JsonProperty("externalName")]
        public string ExternalName { get; set; }

        [JsonProperty("version")]
        public int? Version { get; set; }
    }

    public class Context
    {

        [JsonProperty("app")]
        public string App { get; set; }

        [JsonProperty("service")]
        public string Service { get; set; }

        [JsonProperty("channel")]
        public string Channel { get; set; }

        [JsonProperty("format")]
        public string Format { get; set; }

        [JsonProperty("source")]
        public string Source { get; set; }

        [JsonProperty("role")]
        public string Role { get; set; }

        [JsonProperty("user")]
        public string User { get; set; }

        [JsonProperty("subtype")]
        public string Subtype { get; set; }

        [JsonProperty("order")]
        public string Order { get; set; }

        [JsonProperty("fileName")]
        public string FileName { get; set; }

        [JsonProperty("context")]
        public Context context { get; set; }

        [JsonProperty("jsonData")]
        public JsonData JsonData { get; set; }
    }

    public class Filters
    {

        [JsonProperty("typesCriterion")]
        public IList<string> TypesCriterion { get; set; }
    }

    public class Query
    {

        [JsonProperty("filters")]
        public Filters Filters { get; set; }

        [JsonProperty("id")]
        public string Id { get; set; }
    }

    public class Fields
    {

        [JsonProperty("attributes")]
        public IList<string> Attributes { get; set; }

        [JsonProperty("relationships")]
        public IList<string> Relationships { get; set; }
    }

    public class Params
    {

        [JsonProperty("query")]
        public Query Query { get; set; }

        [JsonProperty("fields")]
        public Fields Fields { get; set; }
    }

    public class Search
    {

        [JsonProperty("params")]
        public Params Params { get; set; }
    }

    public class Settings
    {

        [JsonProperty("includeParent")]
        public object IncludeParent { get; set; }

        [JsonProperty("includeChildren")]
        public string IncludeChildren { get; set; }

        [JsonProperty("includeSiblings")]
        public string IncludeSiblings { get; set; }

        [JsonProperty("includeRelatedEntityExternalIds")]
        public object IncludeRelatedEntityExternalIds { get; set; }

        [JsonProperty("sourceFolder")]
        public string SourceFolder { get; set; }

        [JsonProperty("pattern")]
        public string Pattern { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("version")]
        public string Version { get; set; }

        [JsonProperty("requestforvaluemapping")]
        public string Requestforvaluemapping { get; set; }

        [JsonProperty("search")]
        public Search Search { get; set; }

        [JsonProperty("includeMatchingAttributes")]
        public bool? IncludeMatchingAttributes { get; set; }

        [JsonProperty("includeEnhancerAttributes")]
        public bool? IncludeEnhancerAttributes { get; set; }

        [JsonProperty("includeRelatedEntities")]
        public bool? IncludeRelatedEntities { get; set; }

        [JsonProperty("includeRelatedEntitiesRecursive")]
        public bool? IncludeRelatedEntitiesRecursive { get; set; }

        [JsonProperty("fileType")]
        public string FileType { get; set; }

        [JsonProperty("folderPath")]
        public string FolderPath { get; set; }

        [JsonProperty("useFlatBlobListing")]
        public bool? UseFlatBlobListing { get; set; }
    }

    public class QueryFields
    {

        [JsonProperty("attributes")]
        public IList<object> Attributes { get; set; }
    }

    public class ALL
    {

        [JsonProperty("queryFields")]
        public QueryFields QueryFields { get; set; }
    }

    public class TypesCriterion
    {

        [JsonProperty("_ALL")]
        public ALL ALL { get; set; }
    }

    public class Include
    {

        [JsonProperty("typesCriterion")]
        public TypesCriterion TypesCriterion { get; set; }
    }

    public class Exclude
    {
    }

    public class Filter
    {

        [JsonProperty("include")]
        public Include Include { get; set; }

        [JsonProperty("exclude")]
        public Exclude Exclude { get; set; }
    }

    public class Format
    {

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("version")]
        public string Version { get; set; }

        [JsonProperty("settings")]
        public Settings Settings { get; set; }

        [JsonProperty("batchSize")]
        public int? BatchSize { get; set; }

        [JsonProperty("filter")]
        public Filter Filter { get; set; }

        [JsonProperty("includeFilter")]
        public IList<object> IncludeFilter { get; set; }

        [JsonProperty("excludeFilter")]
        public IList<object> ExcludeFilter { get; set; }
    }

    public class Collect
    {

        [JsonProperty("isDataPersistent")]
        public string IsDataPersistent { get; set; }

        [JsonProperty("channel")]
        public IList<Channel> Channel { get; set; }

        [JsonProperty("format")]
        public Format Format { get; set; }

        [JsonProperty("filter")]
        public Filter Filter { get; set; }

        [JsonProperty("isBinaryStreamPersistent")]
        public string IsBinaryStreamPersistent { get; set; }
    }

    public class Channel
    {

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("settings")]
        public Settings Settings { get; set; }
    }

    public class Publish
    {

        [JsonProperty("isDataPersistent")]
        public string IsDataPersistent { get; set; }

        [JsonProperty("channel")]
        public IList<Channel> Channel { get; set; }

        [JsonProperty("format")]
        public Format Format { get; set; }

        [JsonProperty("filter")]
        public Filter Filter { get; set; }

        [JsonProperty("isBinaryStreamPersistent")]
        public string IsBinaryStreamPersistent { get; set; }
    }


    public class Transform
    {

        [JsonProperty("settings")]
        public Settings Settings { get; set; }

        [JsonProperty("contexts")]
        public IList<Context> Contexts { get; set; }
    }

    public class JsonData
    {

        [JsonProperty("integrationType")]
        public string IntegrationType { get; set; }

        [JsonProperty("isEnabled")]
        public string IsEnabled { get; set; }

        [JsonProperty("collect")]
        public Collect Collect { get; set; }

        [JsonProperty("publish")]
        public Publish Publish { get; set; }

        [JsonProperty("transform")]
        public Transform Transform { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("isMergeableWithCustom")]
        public bool? IsMergeableWithCustom { get; set; }

        [JsonProperty("statusEventEnabled")]
        public bool? StatusEventEnabled { get; set; }

        [JsonProperty("taskSubType")]
        public string TaskSubType { get; set; }

        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("fileName")]
        public string FileName { get; set; }

        [JsonProperty("version")]
        public double? Version { get; set; }

        [JsonProperty("extension")]
        public string Extension { get; set; }

        [JsonProperty("templateFile")]
        public string TemplateFile { get; set; }

        [JsonProperty("fieldOverrides")]
        public IList<object> FieldOverrides { get; set; }
    }

    public class Data
    {

        [JsonProperty("contexts")]
        public IList<Context> Contexts { get; set; }
    }

    public class ConfigObject
    {

        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("properties")]
        public Propertie Properties { get; set; }

        [JsonProperty("data")]
        public Data Data { get; set; }
    }

    public class Response
    {

        [JsonProperty("configObjects")]
        public IList<ConfigObject> ConfigObjects { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("totalRecords")]
        public int TotalRecords { get; set; }
    }

    public class Example
    {

        [JsonProperty("request")]
        public Request Request { get; set; }

        [JsonProperty("response")]
        public Response Response { get; set; }
    }
}
