﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JSonCompareWinApp
{
    public partial class Form1 : Form
    {
        public static string devJsonFile = string.Empty;
        public static string prodJsonFile = string.Empty;
        public Form1()
        {
            InitializeComponent();            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            devJsonFile = "";
            DialogResult result = openFileDialog1.ShowDialog();
            if (result == DialogResult.OK) // Test result.
            {
                string file = openFileDialog1.FileName;
                try
                {
                     devJsonFile = File.ReadAllText(file);
                }
                catch (IOException)
                {
                }
            }         
           

        }

        private void ReadProdJson_Click(object sender, EventArgs e)
        {
              prodJsonFile = "";
               DialogResult result = openFileDialog2.ShowDialog();
            if (result == DialogResult.OK) // Test result.
            {
                string file = openFileDialog2.FileName;
                try
                {
                    prodJsonFile = File.ReadAllText(file);
                }
                catch (IOException)
                {
                }
            }
        }

        private void Compare_Click(object sender, EventArgs e)
        {
            MainClass mc = new MainClass();
            mc.Main(devJsonFile, prodJsonFile);
        }
    }
    public  class MainClass
    {
        public void Main(string devJsonFile="",string prodJsonFile="")
        {
            Console.WriteLine("Integration Profile Json Parsing!");
            //var devJsonFile = "IntegrationProfile_Demo.IntegrationProfile_Dev.json";
            //var prodJsonFile = "IntegrationProfile_Demo.IntegrationProfile_Prod.json";

            var devIntegrationProfile = GetIntegrationProfile(devJsonFile);
            var prodIntegrationProfile = GetIntegrationProfile(prodJsonFile);
            var devConfigs = devIntegrationProfile.Response.ConfigObjects;
            var prodConfigs = prodIntegrationProfile.Response.ConfigObjects;

            //Console.WriteLine("___________________________________");
            //Console.WriteLine($"Config files (Prod):{prodConfigs.Count}");
            //Console.WriteLine($"Config files (Dev):{devConfigs.Count}");

            var prodOnlyConfigNames = prodConfigs.Where(p => !devConfigs.Any(d => d.Name == p.Name)).Select(x => x.Name);
            //Console.WriteLine($"List of Config files (Which are not in Dev):{prodOnlyConfigNames.Count()}");
            //Console.WriteLine("___________________________________");

            DataTable List_Of_Config_Files_Which_NotInDev = new DataTable();
            List_Of_Config_Files_Which_NotInDev.Columns.Add("List_Of_Config_Files_Which_NotInDev)", typeof(string));

            foreach (var item in prodOnlyConfigNames)
            {
                // Console.WriteLine(item);
                List_Of_Config_Files_Which_NotInDev.Rows.Add(item);
            }


            //Console.WriteLine();
            var devOnlyConfigNames = devConfigs.Where(p => !prodConfigs.Any(d => d.Name == p.Name)).Select(x => x.Name);
            //Console.WriteLine($"List of Config files (Which are not in prod):{devOnlyConfigNames.Count()}");
            //Console.WriteLine("___________________________________");

            DataTable List_Of_Config_Files_Which_NotIn_Prod = new DataTable();
            List_Of_Config_Files_Which_NotIn_Prod.Columns.Add("List_Of_Config_Files_Which_NotIn_Prod)", typeof(string));

            foreach (var item in devOnlyConfigNames)
            {
                List_Of_Config_Files_Which_NotIn_Prod.Rows.Add(item);
            }
            //Console.WriteLine();

            //Console.WriteLine($"Common Config files (in Prod and Dev):{prodConfigs.Where(p => devConfigs.Any(d => d.Name == p.Name)).Count()}");
            //Console.WriteLine("___________________________________");
            //Console.WriteLine($"List of Common Config files (in Prod and Dev)");
            //Console.WriteLine("___________________________________");
            var commonConfigNames = prodConfigs.Where(p => devConfigs.Any(d => d.Name == p.Name)).Select(x => x.Name);


            DataTable CommonConfig_files_Prod_and_Dev = new DataTable();
            CommonConfig_files_Prod_and_Dev.Columns.Add("CommonConfig_files_Prod_and_Dev)", typeof(string));

            foreach (var item in commonConfigNames)
            {
                CommonConfig_files_Prod_and_Dev.Rows.Add(item);
            }

            prodJsonFile = NewMethod(prodJsonFile, List_Of_Config_Files_Which_NotInDev, List_Of_Config_Files_Which_NotIn_Prod, CommonConfig_files_Prod_and_Dev);
        }

        private static string NewMethod(string prodJsonFile, DataTable List_Of_Config_Files_Which_NotInDev, DataTable List_Of_Config_Files_Which_NotIn_Prod, DataTable CommonConfig_files_Prod_and_Dev)
        {
            FolderBrowserDialog ofd = new FolderBrowserDialog();
            string ExportPath = string.Empty;
            DialogResult result = ofd.ShowDialog();
            if (result == DialogResult.OK) // Test result.
            {
                ExportPath = ofd.SelectedPath; ;
            }

            DataTableExtensions.WriteToCsvFile(List_Of_Config_Files_Which_NotInDev, ExportPath+ "\\List_Of_Config_Files_Which_NotInDev.csv");
            DataTableExtensions.WriteToCsvFile(List_Of_Config_Files_Which_NotIn_Prod, ExportPath + "\\List_Of_Config_Files_Which_NotIn_Prod.csv");
            DataTableExtensions.WriteToCsvFile(CommonConfig_files_Prod_and_Dev, ExportPath + "\\CommonConfig_files_Prod_and_Dev.csv");
            return prodJsonFile;
        }

        private static IntegrationProfile GetIntegrationProfile(string devJsonFile)
        {
            //var assembly = Assembly.GetExecutingAssembly();
            //using (Stream stream = assembly.GetManifestResourceStream(devJsonFile))
            //using (StreamReader reader = new StreamReader(stream))
            //{
            //    string devJsonString = reader.ReadToEnd();
                return JsonConvert.DeserializeObject<IntegrationProfile>(devJsonFile);
           // }
        }

        
    }

    public static class DataTableExtensions
    {
        public static void WriteToCsvFile(this DataTable dataTable, string filePath)
        {
            StringBuilder fileContent = new StringBuilder();

            foreach (var col in dataTable.Columns)
            {
                fileContent.Append(col.ToString() + ",");
            }

            fileContent.Replace(",", System.Environment.NewLine, fileContent.Length - 1, 1);

            foreach (DataRow dr in dataTable.Rows)
            {
                foreach (var column in dr.ItemArray)
                {
                    fileContent.Append("\"" + column.ToString() + "\",");
                }

                fileContent.Replace(",", System.Environment.NewLine, fileContent.Length - 1, 1);
            }

            System.IO.File.WriteAllText(filePath, fileContent.ToString());
        }
    }
}
